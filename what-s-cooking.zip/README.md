# what-s-cooking
What's Cooking

Running out of idea what to cook? Try What's Cooking!

What's Cooking finds recipes that use as many of the given ingredients as possible and have as little as possible missing ingredients. It shows you the instructions of the recipe too.

Get started by saying something like "Alexa Ask what's cooking give me recipe for chicken".

You can add or remove ingredients. Say 'no' to get the next recipe and say 'yes' to get the instructions.
